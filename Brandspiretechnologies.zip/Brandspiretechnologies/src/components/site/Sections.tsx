import { Link } from "@tanstack/react-router";
import { Quote, Plus } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import casestudy640 from "@/assets/casestudy-640.webp";
import casestudy1280 from "@/assets/casestudy-1280.webp";
import testimonialsBg640 from "@/assets/testimonials-bg-640.webp";
import testimonialsBg1280 from "@/assets/testimonials-bg-1280.webp";


const STEPS = [
  {
    title: "Discovery & Audit",
    desc: "We analyze your brand, competitors and market to find real growth opportunities.",
  },
  {
    title: "Strategy & Planning",
    desc: "A custom roadmap built around your goals, budget and timeline.",
  },
  {
    title: "Execution & Optimization",
    desc: "Campaigns go live, tracked and refined in real time for performance.",
  },
  {
    title: "Reporting & Scaling",
    desc: "Transparent results, monthly reviews, and scaling what works.",
  },
];

export function Process() {
  return (
    <section id="process" className="border-t border-border bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <h2 className="max-w-2xl font-display text-3xl font-extrabold text-navy sm:text-4xl">
          Our Growth <span className="text-primary">Process</span>
        </h2>
        <p className="mt-3 max-w-xl text-base text-muted-foreground sm:text-lg">
          A proven four-step system that turns marketing spend into measurable growth.
        </p>

        <div className="relative mt-14">
          <div className="absolute left-0 right-0 top-6 hidden h-0.5 gradient-orange lg:block" />
          <div className="grid gap-10 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <div key={s.title} className="relative">
                <span className="relative z-10 inline-flex size-12 items-center justify-center rounded-full border-2 border-primary bg-background font-display text-lg font-extrabold text-navy">
                  {i + 1}
                </span>
                <h3 className="mt-5 font-display text-lg font-bold text-navy">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

const STATS = [
  { value: "250+", label: "Brands Grown" },
  { value: "1,200+", label: "Campaigns Launched" },
  { value: "3.2x", label: "Average ROI" },
  { value: "98%", label: "Client Retention" },
];

export function StatsBar() {
  return (
    <section className="gradient-orange py-14 text-primary-foreground">
      <div className="mx-auto grid max-w-7xl gap-8 px-5 text-center sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
        {STATS.map((s) => (
          <div key={s.label}>
            <p className="font-display text-4xl font-extrabold sm:text-5xl">{s.value}</p>
            <p className="mt-1.5 text-sm font-semibold uppercase tracking-widest opacity-90">
              {s.label}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}

const CASES = [
  {
    tag: "E-commerce",
    title: "E-commerce Brand",
    result: "210% increase in organic traffic in 5 months",
  },
  {
    tag: "Local SEO + Ads",
    title: "Local Service Business",
    result: "4x leads through Local SEO + Google Ads",
  },
  {
    tag: "Social Media",
    title: "D2C Startup",
    result: "92% follower growth via Social Media Marketing",
  },
];

export function CaseStudies() {
  return (
    <section id="case-studies" className="border-t border-border bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
          Featured <span className="text-primary">Work</span>
        </h2>
        <p className="mt-3 text-base text-muted-foreground sm:text-lg">
          Real campaigns, real numbers, real growth.
        </p>

        <img
          src={casestudy1280}
          srcSet={`${casestudy640} 640w, ${casestudy1280} 1280w`}
          sizes="(min-width: 1024px) 70vw, 100vw"
          loading="lazy"
          decoding="async"
          width={1280}
          height={854}
          alt="BRANDSPIRE TECHNOLOGIES team and a client reviewing campaign growth charts on a laptop"
          className="mt-10 aspect-[21/9] w-full rounded-2xl object-cover card-shadow"
        />

        <div className="mt-12 grid gap-6 lg:grid-cols-3">

          {CASES.map((c) => (
            <article
              key={c.title}
              className="group flex flex-col rounded-2xl border border-border bg-card p-7 transition-all hover:-translate-y-1 hover:border-primary/40 hover:card-shadow"
            >
              <span className="inline-flex w-fit rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary">
                {c.tag}
              </span>
              <h3 className="mt-5 font-display text-xl font-bold text-navy">{c.title}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                {c.result}
              </p>
              <Link to="/case-studies" className="mt-6 text-sm font-bold text-primary">
                View Case Study →
              </Link>

            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

const TESTIMONIALS = [
  {
    quote:
      "BRANDSPIRE rebuilt our entire search presence. We went from invisible to page one for our most valuable keywords in under six months.",
    name: "Ananya Rao",
    company: "Founder, Lumina Home",
  },
  {
    quote:
      "Their Google Ads team cut our cost per lead by nearly 40% while doubling volume. The reporting is the clearest we've ever had.",
    name: "Rahul Menon",
    company: "Director, Vertex Interiors",
  },
  {
    quote:
      "The social content finally looks like the brand we always wanted to be — and it's actually driving sales, not just likes.",
    name: "Priya Sharma",
    company: "CMO, Nuvo Wellness",
  },
  {
    quote:
      "Responsive, accountable and genuinely invested in our numbers. It feels like an in-house team, not an agency.",
    name: "Karan Gupta",
    company: "CEO, Stridewear",
  },
];

export function Testimonials() {
  return (
    <section className="relative isolate overflow-hidden bg-muted py-20 lg:py-28">
      <img
        src={testimonialsBg1280}
        srcSet={`${testimonialsBg640} 640w, ${testimonialsBg1280} 1280w`}
        sizes="100vw"
        loading="lazy"
        decoding="async"
        width={1280}
        height={720}
        alt="Blurred view of a collaborative marketing workspace"
        className="absolute inset-0 -z-10 size-full object-cover opacity-15"
      />
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
          What Our <span className="text-primary">Clients Say</span>
        </h2>


        <div className="mt-12 flex snap-x snap-mandatory gap-6 overflow-x-auto pb-4">
          {TESTIMONIALS.map((t) => (
            <figure
              key={t.name}
              className="w-[85%] shrink-0 snap-start rounded-2xl bg-card p-7 card-shadow sm:w-[46%] lg:w-[31%]"
            >
              <Quote className="size-8 text-primary" />
              <blockquote className="mt-4 text-base leading-relaxed text-navy">
                "{t.quote}"
              </blockquote>
              <figcaption className="mt-6">
                <p className="font-display font-bold text-navy">{t.name}</p>
                <p className="text-sm text-muted-foreground">{t.company}</p>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

const CLIENTS = [
  "Lumina Home",
  "Vertex Interiors",
  "Nuvo Wellness",
  "Stridewear",
  "Kavya Foods",
  "Orbit Fintech",
  "Northline Realty",
  "Zenith Clinics",
];

export function TrustedBy() {
  return (
    <section className="border-y border-border bg-background py-12">
      <p className="text-center text-xs font-bold uppercase tracking-[0.25em] text-muted-foreground">
        Trusted by growing brands
      </p>
      <div className="marquee mt-8">
        <div className="marquee-track">
          {[...CLIENTS, ...CLIENTS].map((name, i) => (
            <span
              key={`${name}-${i}`}
              className="shrink-0 px-8 font-display text-xl font-extrabold text-muted-foreground/50 transition-colors hover:text-navy"
            >
              {name}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

const FAQS = [
  {
    q: "How long does it take to see results?",
    a: "Paid campaigns can generate leads within the first two weeks. SEO and content typically show meaningful movement in 8–12 weeks, compounding from month four onward.",
  },
  {
    q: "Do you offer customized packages?",
    a: "Always. Every engagement is scoped around your goals, budget and internal capacity — we don't sell fixed templates.",
  },
  {
    q: "Which industries do you work with?",
    a: "E-commerce, D2C, real estate, healthcare, education, SaaS, hospitality and local service businesses, among others.",
  },
  {
    q: "How do you report campaign performance?",
    a: "You get a live dashboard plus a monthly review call covering spend, leads, cost per acquisition and the next month's plan.",
  },
  {
    q: "What's included in a free consultation?",
    a: "A review of your current marketing, a competitor snapshot, and a clear set of recommendations you can act on with or without us.",
  },
];

export function FAQ({
  items = FAQS,
  title = "Frequently Asked",
  highlight = "Questions",
}: {
  items?: { q: string; a: string }[];
  title?: string;
  highlight?: string;
}) {
  return (
    <section id="faq" className="border-t border-border bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-3xl px-5 lg:px-8">
        <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
          {title} <span className="text-primary">{highlight}</span>
        </h2>

        <Accordion type="single" collapsible className="mt-10 space-y-4">
          {items.map((f, i) => (
            <AccordionItem
              key={f.q}
              value={`item-${i}`}
              className="rounded-2xl border border-border bg-card px-5 [&[data-state=open]]:border-primary/40"
            >
              <AccordionTrigger className="gap-4 text-left font-display text-base font-bold text-navy hover:no-underline [&>svg:last-child]:hidden">
                {f.q}
                <Plus className="size-5 shrink-0 text-primary transition-transform duration-200 [[data-state=open]_&]:rotate-45" />
              </AccordionTrigger>
              <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                {f.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

const POSTS = [
  {
    tag: "SEO",
    title: "5 SEO Trends Shaping 2026",
    excerpt:
      "AI overviews, entity-first content and the death of thin blog posts — what actually moves rankings this year.",
  },
  {
    tag: "Google Ads",
    title: "How to Lower Your Google Ads CPC",
    excerpt:
      "Seven structural changes that reduce cost per click without shrinking your reach or lead volume.",
  },
  {
    tag: "WhatsApp",
    title: "WhatsApp Marketing: A Beginner's Guide",
    excerpt:
      "From API setup to your first broadcast — a practical playbook for high open-rate customer messaging.",
  },
];

export function BlogPreview() {
  return (
    <section id="blog" className="border-t border-border bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
          Insights & <span className="text-primary">Ideas</span>
        </h2>
        <p className="mt-3 text-base text-muted-foreground sm:text-lg">
          Practical marketing thinking from the BRANDSPIRE team.
        </p>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {POSTS.map((p) => (
            <article
              key={p.title}
              className="group flex flex-col rounded-2xl border border-border bg-card p-7 transition-all hover:-translate-y-1 hover:border-primary/40 hover:card-shadow"
            >
              <span className="inline-flex w-fit rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary">
                {p.tag}
              </span>
              <h3 className="mt-5 font-display text-xl font-bold leading-snug text-navy">
                {p.title}
              </h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                {p.excerpt}
              </p>
              <Link to="/blog" className="mt-6 text-sm font-bold text-primary">
                Read More →
              </Link>

            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ServicesLinkStrip() {
  return (
    <Link to="/services" className="text-sm font-bold text-primary">
      Explore all services →
    </Link>
  );
}
