import { useEffect, useRef, useState } from "react";
import { TrendingUp, Users, Search, Target } from "lucide-react";

function useCountUp(target: number, duration = 1800) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      setValue(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

function TrafficCard() {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 card-shadow">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
          Website Traffic
        </p>
        <TrendingUp className="size-4 text-primary" />
      </div>
      <p className="mt-1 font-display text-2xl font-extrabold text-navy">+184%</p>
      <p className="text-xs font-medium text-muted-foreground">in 6 months</p>
      <svg viewBox="0 0 240 80" className="mt-3 h-20 w-full">
        <defs>
          <linearGradient id="fillA" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.35" />
            <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M0 70 L40 62 L80 66 L120 44 L160 40 L200 20 L240 8 L240 80 L0 80 Z"
          fill="url(#fillA)"
        />
        <path
          d="M0 70 L40 62 L80 66 L120 44 L160 40 L200 20 L240 8"
          fill="none"
          stroke="var(--primary)"
          strokeWidth="3"
          strokeLinecap="round"
          className="animate-draw"
        />
      </svg>
    </div>
  );
}

function LeadsCard() {
  const leads = useCountUp(1240);
  return (
    <div className="rounded-2xl bg-navy p-5 text-navy-foreground card-shadow">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold uppercase tracking-widest text-navy-foreground/60">
          Lead Generation
        </p>
        <Users className="size-4 text-primary" />
      </div>
      <p className="mt-2 font-display text-3xl font-extrabold text-primary tabular-nums">
        {leads.toLocaleString()}
      </p>
      <p className="text-xs font-medium text-navy-foreground/70">
        Qualified Leads This Quarter
      </p>
    </div>
  );
}

function SocialCard() {
  const bars = [38, 52, 44, 68, 80, 96];
  return (
    <div className="rounded-2xl border border-border bg-card p-5 card-shadow">
      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Social Growth
      </p>
      <p className="mt-1 font-display text-xl font-extrabold text-navy">
        Follower Growth <span className="text-primary">+92%</span>
      </p>
      <div className="mt-4 flex h-20 items-end gap-2">
        {bars.map((h, i) => (
          <div
            key={i}
            className="animate-bar flex-1 rounded-t-md gradient-orange"
            style={{ height: `${h}%`, animationDelay: `${i * 90}ms` }}
          />
        ))}
      </div>
    </div>
  );
}

function RankingsCard() {
  const kw = useCountUp(340);
  return (
    <div className="rounded-2xl border border-border bg-card p-5 card-shadow">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
          Search Rankings
        </p>
        <Search className="size-4 text-primary" />
      </div>
      <p className="mt-2 font-display text-2xl font-extrabold text-navy tabular-nums">
        {kw}+
      </p>
      <p className="text-xs font-medium text-muted-foreground">Keywords in Top 10</p>
    </div>
  );
}

function CampaignCard() {
  const circumference = 2 * Math.PI * 34;
  return (
    <div className="rounded-2xl border border-border bg-card p-5 card-shadow">
      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Campaign Performance
      </p>
      <div className="mt-3 flex items-center gap-4">
        <svg viewBox="0 0 80 80" className="size-20 -rotate-90">
          <circle cx="40" cy="40" r="34" fill="none" stroke="var(--muted)" strokeWidth="10" />
          <circle
            cx="40"
            cy="40"
            r="34"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference * 0.32}
          />
        </svg>
        <div>
          <p className="font-display text-xl font-extrabold text-navy">68%</p>
          <p className="text-xs font-medium text-muted-foreground">Spend-to-conversion ratio</p>
        </div>
      </div>
    </div>
  );
}

function RoiCard() {
  return (
    <div className="rounded-2xl gradient-orange p-5 text-primary-foreground glow-orange">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold uppercase tracking-widest opacity-80">
          Conversion Rate
        </p>
        <Target className="size-4" />
      </div>
      <p className="mt-2 font-display text-3xl font-extrabold">+3.2x</p>
      <p className="text-xs font-semibold opacity-90">Average ROI</p>
    </div>
  );
}

export function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  return (
    <section id="home" className="relative overflow-hidden bg-background">
      <div className="pointer-events-none absolute -right-32 -top-40 size-[34rem] rounded-full bg-accent blur-3xl" />
      <div className="relative mx-auto grid max-w-7xl gap-14 px-5 pb-20 pt-14 lg:grid-cols-[1fr_1.05fr] lg:items-center lg:px-8 lg:pb-28 lg:pt-20">
        <div className="animate-rise">
          <p className="mb-5 inline-flex items-center rounded-full border border-primary/30 bg-accent px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-primary">
            Digital Marketing · Growing Brands
          </p>
          <h1 className="font-display text-4xl font-extrabold leading-[1.05] text-navy sm:text-5xl lg:text-6xl">
            Grow Your <span className="text-primary">Brand.</span>
            <br />
            Inspire Greater <span className="text-primary">Success.</span>
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            BRANDSPIRE TECHNOLOGIES helps businesses increase online visibility, generate
            quality leads and achieve measurable growth through creative and
            performance-driven digital marketing strategies.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="/contact"
              className="rounded-full bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground transition-all hover:glow-orange hover:brightness-105"
            >
              Start Growing
            </a>
            <a
              href="#services"
              className="rounded-full border-2 border-primary bg-background px-7 py-3.5 text-sm font-bold text-navy transition-colors hover:bg-accent"
            >
              Explore Services
            </a>
          </div>
          <p className="mt-6 text-sm font-medium text-muted-foreground">
            Trusted by growing brands across industries — from local businesses to national
            enterprises.
          </p>
        </div>

        <div ref={ref} className="animate-float">
          <div className="rounded-3xl border border-border bg-muted/50 p-4 card-shadow sm:p-6">
            <div className="mb-4 flex items-center gap-2">
              <span className="size-2.5 rounded-full bg-primary" />
              <span className="size-2.5 rounded-full bg-navy/30" />
              <span className="size-2.5 rounded-full bg-navy/15" />
              <p className="ml-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Growth Dashboard
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <TrafficCard />
              </div>
              <LeadsCard />
              <RankingsCard />
              <SocialCard />
              <div className="grid gap-4">
                <CampaignCard />
                <RoiCard />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
