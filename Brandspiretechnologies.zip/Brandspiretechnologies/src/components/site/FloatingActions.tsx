import { Phone } from "lucide-react";
import { CONTACT } from "@/data/contact";

export function FloatingActions() {
  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      <a
        href={CONTACT.phoneHref}
        aria-label={`Call BRANDSPIRE TECHNOLOGIES on ${CONTACT.phoneDisplay}`}
        className="inline-flex size-12 items-center justify-center rounded-full border border-primary/30 bg-card text-primary card-shadow transition-transform hover:scale-105"
      >
        <Phone className="size-5" />
      </a>
      <a
        href={CONTACT.whatsapp}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with BRANDSPIRE TECHNOLOGIES on WhatsApp"
        className="pulse-glow inline-flex size-14 items-center justify-center rounded-full gradient-orange text-primary-foreground transition-transform hover:scale-105"
      >
        <svg viewBox="0 0 24 24" className="size-7" fill="currentColor" aria-hidden="true">
          <path d="M12.04 2c-5.52 0-10 4.48-10 10 0 1.77.46 3.5 1.34 5.02L2 22l5.13-1.34A9.96 9.96 0 0 0 12.04 22c5.52 0 10-4.48 10-10s-4.48-10-10-10Zm0 18.17c-1.6 0-3.17-.43-4.53-1.24l-.33-.19-3.05.8.81-2.97-.21-.34a8.15 8.15 0 1 1 7.31 3.94Zm4.5-6.1c-.25-.13-1.46-.72-1.68-.8-.23-.08-.39-.13-.56.13-.16.25-.64.8-.79.97-.14.16-.29.18-.54.06-.25-.13-1.04-.38-1.98-1.22-.73-.65-1.23-1.46-1.37-1.71-.14-.25-.02-.39.11-.51.11-.11.25-.29.37-.44.13-.15.17-.25.25-.42.08-.16.04-.31-.02-.44-.06-.13-.56-1.35-.77-1.84-.2-.48-.4-.42-.56-.43h-.48c-.16 0-.42.06-.64.31-.22.25-.84.82-.84 2s.86 2.32.98 2.48c.13.16 1.7 2.6 4.12 3.64.58.25 1.03.4 1.38.51.58.19 1.11.16 1.53.1.47-.07 1.46-.6 1.66-1.18.2-.58.2-1.07.14-1.18-.06-.1-.22-.16-.47-.29Z" />
        </svg>
      </a>
    </div>
  );
}
