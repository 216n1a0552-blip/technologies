const logo = { url: "/brandspire-logo.png" };
import { useEffect, useState } from "react";
import { Menu, X, ChevronDown, Phone, Home, Users, Briefcase, FileText, Newspaper, Mail } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { SERVICES } from "@/data/services";
import { CONTACT } from "@/data/contact";

const NAV = [
  { label: "Home", href: "/#home", icon: Home },
  { label: "About Us", to: "/about" as const, icon: Users },
  { label: "Services", to: "/services" as const, icon: Briefcase, hasDropdown: true },
  { label: "Case Studies", to: "/case-studies" as const, icon: FileText },
  { label: "Blog", to: "/blog" as const, icon: Newspaper },
  { label: "Contact", to: "/contact" as const, icon: Mail },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 bg-background transition-shadow ${
        scrolled ? "shadow-[0_6px_24px_-18px_rgba(11,31,58,0.8)]" : ""
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 py-3 lg:px-8">
        <Link to="/" className="shrink-0">
          <img
            src={logo.url}
            alt="BRANDSPIRE TECHNOLOGIES — digital marketing agency"
            className="h-14 w-auto max-w-[62vw] object-contain sm:h-16 md:h-20 lg:h-24"
          />
        </Link>

        <nav className="hidden items-center gap-8 text-sm font-semibold lg:flex">
          {NAV.map((item) => {
            const Icon = item.icon;
            if (item.hasDropdown) {
              return (
                <div key={item.label} className="group relative">
                  <Link to={item.to!} className="nav-link inline-flex items-center gap-1.5">
                    <Icon className="size-4" />
                    {item.label}
                    <ChevronDown className="size-4" />
                  </Link>
                  <div className="invisible absolute left-1/2 top-full z-50 w-72 -translate-x-1/2 pt-4 opacity-0 transition-all group-hover:visible group-hover:opacity-100">
                    <div className="rounded-2xl border border-border bg-card p-2 card-shadow">
                      {SERVICES.map((s) => (
                        <Link
                          key={s.slug}
                          to="/services/$slug"
                          params={{ slug: s.slug }}
                          className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-navy transition-colors hover:bg-accent hover:text-primary"
                        >
                          <s.icon className="size-4 text-primary" />
                          {s.navTitle}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              );
            }
            if (item.href) {
              return (
                <a key={item.label} href={item.href} className="nav-link inline-flex items-center gap-1.5 transition-colors">
                  <Icon className="size-4" />
                  {item.label}
                </a>
              );
            }
            return (
              <Link key={item.label} to={item.to!} className="nav-link inline-flex items-center gap-1.5 transition-colors">
                <Icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={CONTACT.phoneHref}
            className="hidden items-center gap-2 text-sm font-bold text-navy transition-colors hover:text-primary xl:inline-flex"
          >
            <Phone className="size-4 text-primary" />
            {CONTACT.phoneDisplay}
          </a>
          <Link
            to="/contact"
            className="hidden rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground transition-all hover:glow-orange hover:brightness-105 md:inline-flex"
          >
            Get Free Consultation
          </Link>

          <button
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
            className="rounded-md p-2 text-navy lg:hidden"
          >
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="max-h-[75vh] overflow-y-auto border-t border-border bg-background px-5 pb-5 lg:hidden">
          <nav className="flex flex-col gap-4 pt-4 text-sm font-semibold text-navy">
            {NAV.map((item) => {
              const Icon = item.icon;
              if (item.hasDropdown) {
                return (
                  <div key={item.label}>
                    <Link to={item.to!} onClick={() => setOpen(false)} className="inline-flex items-center gap-2">
                      <Icon className="size-4" />
                      {item.label}
                    </Link>
                    <div className="mt-3 flex flex-col gap-3 border-l border-border pl-4 text-sm font-medium text-muted-foreground">
                      {SERVICES.map((s) => (
                        <Link
                          key={s.slug}
                          to="/services/$slug"
                          params={{ slug: s.slug }}
                          onClick={() => setOpen(false)}
                        >
                          {s.navTitle}
                        </Link>
                      ))}
                    </div>
                  </div>
                );
              }
              if (item.href) {
                return (
                  <a key={item.label} href={item.href} onClick={() => setOpen(false)} className="inline-flex items-center gap-2">
                    <Icon className="size-4" />
                    {item.label}
                  </a>
                );
              }
              return (
                <Link key={item.label} to={item.to!} onClick={() => setOpen(false)} className="inline-flex items-center gap-2">
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
            <a href={CONTACT.phoneHref} className="text-primary">
              {CONTACT.phoneDisplay}
            </a>
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="mt-1 rounded-full bg-primary px-5 py-2.5 text-center font-bold text-primary-foreground"
            >
              Get Free Consultation
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
