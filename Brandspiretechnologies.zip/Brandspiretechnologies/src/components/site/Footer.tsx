const logo = { url: "/brandspire-logo.png" };
import { Instagram, Linkedin, Facebook, Mail, Phone, MapPin } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { SERVICES } from "@/data/services";
import { CONTACT } from "@/data/contact";

const COMPANY = [
  { label: "About Us", to: "/about" as const },
  { label: "Case Studies", to: "/case-studies" as const },
  { label: "Blog", to: "/blog" as const },
  { label: "All Services", to: "/services" as const },
];


const SOCIALS = [
  { icon: Instagram, label: "Instagram" },
  { icon: Linkedin, label: "LinkedIn" },
  { icon: Facebook, label: "Facebook" },
];


export function Footer() {
  return (
    <footer id="contact" className="bg-navy text-navy-foreground">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-[1.4fr_1fr_0.8fr_1.1fr] lg:px-8">
        <div>
          <img
            src="/brandspire-logo.png"
            alt="BRANDSPIRE TECHNOLOGIES logo"
            className="footer-logo-glow h-14 w-auto object-contain p-2"
          />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-navy-foreground/70">
            BRANDSPIRE TECHNOLOGIES — Performance-driven digital marketing for ambitious brands.
          </p>
        </div>

        <div>
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">
            Services
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm text-navy-foreground/75">
            {SERVICES.map((s) => (
              <li key={s.title}>
                <Link
                  to="/services/$slug"
                  params={{ slug: s.slug }}
                  className="transition-colors hover:text-primary"
                >
                  {s.navTitle}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">
            Company
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm text-navy-foreground/75">
            {COMPANY.map((c) => (
              <li key={c.label}>
                <Link to={c.to} className="transition-colors hover:text-primary">
                  {c.label}
                </Link>
              </li>
            ))}

            <li>
              <Link to="/contact" className="transition-colors hover:text-primary">
                Contact
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">
            Get in Touch
          </h3>
          <ul className="mt-4 space-y-3 text-sm text-navy-foreground/75">
            <li className="flex items-start gap-3">
              <Mail className="mt-0.5 size-4 shrink-0 text-primary" />
              <a href={CONTACT.emailHref} className="hover:text-primary">
                {CONTACT.email}
              </a>
            </li>
            <li className="flex items-start gap-3">
              <Phone className="mt-0.5 size-4 shrink-0 text-primary" />
              <a href={CONTACT.phoneHref} className="hover:text-primary">
                {CONTACT.phoneDisplay}
              </a>
            </li>
            <li className="flex items-start gap-3">
              <MapPin className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>{CONTACT.address}</span>
            </li>
          </ul>

          <div className="mt-5 flex gap-3">
            {SOCIALS.map(({ icon: Icon, label }) => (
              <a
                key={label}
                href="#contact"
                aria-label={label}
                className="inline-flex size-10 items-center justify-center rounded-full border border-primary/40 text-primary transition-all hover:glow-orange hover:gradient-orange hover:text-primary-foreground"
              >
                <Icon className="size-4" />
              </a>
            ))}
            <a
              href="#contact"
              aria-label="X"
              className="inline-flex size-10 items-center justify-center rounded-full border border-primary/40 text-primary transition-all hover:glow-orange hover:gradient-orange hover:text-primary-foreground"
            >
              <svg viewBox="0 0 24 24" className="size-4" fill="currentColor" aria-hidden="true">
                <path d="M18.9 2H22l-7.1 8.1L23.2 22h-6.5l-5.1-6.6L5.7 22H2.6l7.6-8.7L1.2 2h6.7l4.6 6.1L18.9 2Zm-1.1 18h1.7L7.3 3.8H5.5L17.8 20Z" />
              </svg>
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-navy-foreground/10">
        <p className="mx-auto max-w-7xl px-5 py-6 text-center text-xs text-navy-foreground/60 lg:px-8">
          © 2026 BRANDSPIRE TECHNOLOGIES. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
