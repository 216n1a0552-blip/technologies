import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, CheckCircle2 } from "lucide-react";
import { submitEnquiry } from "@/lib/contact.functions";
import { SERVICES } from "@/data/services";

const field =
  "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-navy outline-none transition-colors focus:border-primary";

export function ContactForm({ source = "website" }: { source?: string }) {
  const send = useServerFn(submitEnquiry);
  const [status, setStatus] = useState<"idle" | "sending" | "done">("idle");
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setStatus("sending");
    setError(null);
    try {
      await send({
        data: {
          name: String(fd.get("name") ?? ""),
          phone: String(fd.get("phone") ?? ""),
          email: String(fd.get("email") ?? ""),
          service: String(fd.get("service") ?? ""),
          message: String(fd.get("message") ?? ""),
          source,
        },
      });
      form.reset();
      setStatus("done");
    } catch (err) {
      setStatus("idle");
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    }
  }

  if (status === "done") {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center card-shadow">
        <CheckCircle2 className="mx-auto size-10 text-primary" />
        <h3 className="mt-4 font-display text-xl font-bold text-navy">Thank you — we've got it</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Our team will get back to you within one business day. Need it faster? Call us on{" "}
          <a href="tel:+918143792269" className="font-semibold text-primary">
            +91 81437 92269
          </a>
          .
        </p>
      </div>
    );
  }

  return (
    <form
      onSubmit={onSubmit}
      className="rounded-2xl border border-border bg-card p-6 card-shadow sm:p-8"
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="cf-name" className="text-xs font-bold uppercase tracking-wider text-navy">
            Name
          </label>
          <input id="cf-name" name="name" required className={`mt-2 ${field}`} placeholder="Your full name" />
        </div>
        <div>
          <label htmlFor="cf-phone" className="text-xs font-bold uppercase tracking-wider text-navy">
            Phone
          </label>
          <input
            id="cf-phone"
            name="phone"
            type="tel"
            required
            className={`mt-2 ${field}`}
            placeholder="+91 ..."
          />
        </div>
        <div>
          <label htmlFor="cf-email" className="text-xs font-bold uppercase tracking-wider text-navy">
            Email
          </label>
          <input
            id="cf-email"
            name="email"
            type="email"
            required
            className={`mt-2 ${field}`}
            placeholder="you@company.com"
          />
        </div>
        <div>
          <label
            htmlFor="cf-service"
            className="text-xs font-bold uppercase tracking-wider text-navy"
          >
            Service Interested In
          </label>
          <select id="cf-service" name="service" className={`mt-2 ${field}`} defaultValue="">
            <option value="">Select a service</option>
            {SERVICES.map((s) => (
              <option key={s.slug} value={s.title}>
                {s.title}
              </option>
            ))}
            <option value="Not sure yet">Not sure yet</option>
          </select>
        </div>
      </div>

      <div className="mt-4">
        <label htmlFor="cf-message" className="text-xs font-bold uppercase tracking-wider text-navy">
          Message
        </label>
        <textarea
          id="cf-message"
          name="message"
          required
          rows={4}
          className={`mt-2 ${field}`}
          placeholder="Tell us about your goals, budget and timelines."
        />
      </div>

      {error && <p className="mt-4 text-sm font-semibold text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={status === "sending"}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full gradient-orange px-6 py-3.5 text-sm font-bold text-primary-foreground transition-all hover:glow-orange disabled:opacity-70 sm:w-auto"
      >
        {status === "sending" && <Loader2 className="size-4 animate-spin" />}
        Get My Free Consultation
      </button>
      <p className="mt-3 text-xs text-muted-foreground">
        Your enquiry goes straight to our team at{" "}
        <a href="mailto:brandspiretechnologies@gmail.com" className="font-semibold text-primary">
          brandspiretechnologies@gmail.com
        </a>
        .
      </p>
    </form>
  );
}
