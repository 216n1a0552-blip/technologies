import { BarChart3, Compass, FileBarChart, Sparkles, Headphones, LineChart } from "lucide-react";
import { Link } from "@tanstack/react-router";
import team640 from "@/assets/team-640.webp";
import team1280 from "@/assets/team-1280.webp";
import strategy640 from "@/assets/strategy-640.webp";
import strategy1280 from "@/assets/strategy-1280.webp";


const REASONS = [
  {
    icon: BarChart3,
    title: "ROI-Focused Campaigns",
    desc: "Every rupee is tracked. We optimize toward revenue, not vanity metrics.",
  },
  {
    icon: Compass,
    title: "Custom Marketing Strategies",
    desc: "No templates. Every strategy is built around your business goals and audience.",
  },
  {
    icon: FileBarChart,
    title: "Transparent Reporting",
    desc: "Real-time dashboards and monthly reports — you always know where your budget goes.",
  },
  {
    icon: Sparkles,
    title: "Creative Digital Solutions",
    desc: "Bold creative that gets noticed, backed by data that gets results.",
  },
  {
    icon: Headphones,
    title: "Dedicated Client Support",
    desc: "A dedicated account manager, always reachable, always accountable.",
  },
  {
    icon: LineChart,
    title: "Measurable Business Growth",
    desc: "We measure success in leads, sales and revenue — not impressions.",
  },
];

export function WhyUs() {
  return (
    <section id="about" className="bg-navy py-20 text-navy-foreground lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div>
            <h2 className="max-w-3xl font-display text-3xl font-extrabold sm:text-4xl">
              Why Brands Choose <span className="text-primary">BRANDSPIRE</span>
            </h2>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-navy-foreground/75">
              We're a digital marketing agency in Hyderabad built around one idea: marketing should
              be measured in revenue. From{" "}
              <Link to="/services/$slug" params={{ slug: "seo" }} className="text-primary underline-offset-4 hover:underline">
                SEO services
              </Link>{" "}
              to{" "}
              <Link to="/services/$slug" params={{ slug: "google-ads" }} className="text-primary underline-offset-4 hover:underline">
                Google Ads management
              </Link>
              , every channel we run reports back to your bottom line.
            </p>
          </div>
          <img
            src={team1280}
            srcSet={`${team640} 640w, ${team1280} 1280w`}
            sizes="(min-width: 1024px) 45vw, 100vw"
            loading="lazy"
            decoding="async"
            width={1280}
            height={854}
            alt="BRANDSPIRE TECHNOLOGIES team collaborating on a digital marketing campaign in a modern Hyderabad office"
            className="aspect-[3/2] w-full rounded-2xl object-cover"
          />
        </div>

        <div className="mt-14 grid gap-x-10 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {REASONS.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex gap-4">
              <span className="inline-flex size-11 shrink-0 items-center justify-center rounded-xl border border-primary/40 text-primary">
                <Icon className="size-5" />
              </span>
              <div>
                <h3 className="font-display text-lg font-bold">{title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-navy-foreground/70">{desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-14 grid items-center gap-10 lg:grid-cols-[1.1fr_1fr]">
          <img
            src={strategy1280}
            srcSet={`${strategy640} 640w, ${strategy1280} 1280w`}
            sizes="(min-width: 1024px) 50vw, 100vw"
            loading="lazy"
            decoding="async"
            width={1280}
            height={854}
            alt="BRANDSPIRE strategist presenting a campaign analytics dashboard to a client"
            className="aspect-[3/2] w-full rounded-2xl object-cover"
          />
          <div>
            <h3 className="font-display text-2xl font-bold">Strategy you can actually see</h3>
            <p className="mt-3 text-sm leading-relaxed text-navy-foreground/75">
              Every account gets a live performance dashboard and a monthly review with the
              strategist running your campaigns — no black boxes, no filler slides.
            </p>
            <Link
              to="/contact"
              className="mt-6 inline-flex rounded-full gradient-orange px-6 py-3 text-sm font-bold text-primary-foreground hover:glow-orange"
            >
              Talk to a strategist
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

export function CallToAction() {
  return (
    <section id="cta" className="gradient-orange py-20 text-primary-foreground lg:py-24">
      <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
        <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
          Ready to Build a Powerful Digital Brand?
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-base font-light leading-relaxed sm:text-lg">
          Let's create a growth strategy tailored to your business — no obligation, just a clear
          plan forward.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link
            to="/contact"
            className="inline-flex rounded-full bg-background px-8 py-4 text-sm font-bold text-primary transition-transform hover:-translate-y-0.5"
          >
            Book Your Free Consultation
          </Link>
          <a
            href="tel:+918143792269"
            className="inline-flex rounded-full border border-primary-foreground/50 px-8 py-4 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5"
          >
            Call +91 81437 92269
          </a>
        </div>
      </div>
    </section>
  );

}
