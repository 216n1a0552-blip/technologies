import { ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { SERVICES } from "@/data/services";

export { SERVICES };

export function Services() {
  return (
    <section id="services" className="border-t border-border bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="max-w-2xl">
          <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
            What We <span className="text-primary">Do Best</span>
          </h2>
          <p className="mt-3 text-base text-muted-foreground sm:text-lg">
            Full-funnel digital marketing built to convert.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map(({ icon: Icon, title, desc, slug }) => (
            <article
              key={title}
              className="group flex flex-col rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/40 hover:card-shadow"
            >
              <span className="mb-5 inline-flex size-12 items-center justify-center rounded-xl bg-accent text-primary transition-colors group-hover:gradient-orange group-hover:text-primary-foreground">
                <Icon className="size-6" />
              </span>
              <h3 className="font-display text-lg font-bold leading-snug text-navy">{title}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{desc}</p>
              <Link
                to="/services/$slug"
                params={{ slug }}
                className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold text-primary"
              >
                Learn More
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
