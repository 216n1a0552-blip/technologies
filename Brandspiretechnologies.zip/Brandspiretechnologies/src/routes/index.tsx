import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Hero } from "@/components/site/Hero";
import { Services } from "@/components/site/Services";
import { WhyUs, CallToAction } from "@/components/site/WhyUs";
import {
  Process,
  StatsBar,
  CaseStudies,
  Testimonials,
  TrustedBy,
  FAQ,
  BlogPreview,
} from "@/components/site/Sections";
import { Footer } from "@/components/site/Footer";
import { FloatingActions } from "@/components/site/FloatingActions";
import { SITE_URL } from "@/data/contact";
import { organizationSchema, ldScript } from "@/data/schema";

const TITLE = "Digital Marketing Agency in Hyderabad | BRANDSPIRE TECHNOLOGIES";
const DESC =
  "BRANDSPIRE TECHNOLOGIES is a digital marketing agency in Hyderabad delivering SEO, Google Ads management, Meta Ads and content marketing that drive measurable leads and ROI.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: SITE_URL }],
    scripts: [ldScript(organizationSchema)],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <TrustedBy />
        <Services />
        <WhyUs />
        <Process />
        <StatsBar />
        <CaseStudies />
        <Testimonials />
        <FAQ />
        <BlogPreview />
        <CallToAction />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
