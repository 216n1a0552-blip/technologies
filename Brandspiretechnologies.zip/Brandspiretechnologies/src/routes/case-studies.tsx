import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { FloatingActions } from "@/components/site/FloatingActions";
import { SITE_URL } from "@/data/contact";
import { organizationSchema, ldScript } from "@/data/schema";

const TITLE = "Case Studies | Digital Marketing Results | BRANDSPIRE TECHNOLOGIES";
const DESC =
  "See how BRANDSPIRE TECHNOLOGIES grew organic traffic, leads and social reach for e-commerce, local service and D2C brands with SEO, Google Ads and social media marketing.";

export const Route = createFileRoute("/case-studies")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/case-studies` }],
    scripts: [ldScript(organizationSchema)],
  }),
  component: CaseStudiesPage,
});

const CASES = [
  {
    tag: "E-commerce",
    title: "E-commerce Brand",
    result: "210% increase in organic traffic in 5 months",
    challenge:
      "Thousands of product pages competing with each other, thin category content and almost no visibility for high-intent buying keywords.",
    approach:
      "Technical clean-up, category-first content architecture, internal linking and a rolling programme of buyer-intent landing pages.",
    outcome:
      "Organic sessions grew 210% in five months, with category pages driving the majority of new revenue.",
  },
  {
    tag: "Local SEO + Ads",
    title: "Local Service Business",
    result: "4x leads through Local SEO + Google Ads",
    challenge:
      "Strong offline reputation but almost no presence in local map results, and paid budget spent on broad, low-intent searches.",
    approach:
      "Google Business Profile optimisation, location landing pages, review generation and a tightly structured search campaign around service-plus-area terms.",
    outcome:
      "Qualified enquiries increased 4x while cost per lead dropped through better match and negative keyword control.",
  },
  {
    tag: "Social Media",
    title: "D2C Startup",
    result: "92% follower growth via Social Media Marketing",
    challenge:
      "A new brand with no audience, inconsistent posting and creative that failed to hold attention past the first second.",
    approach:
      "A monthly content system built on hooks, short-form video and community replies, supported by targeted Meta Ads for the best organic performers.",
    outcome:
      "Follower base grew 92% with a steady stream of inbound DMs converting into first-time customers.",
  },
];

function CaseStudiesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <section className="border-b border-border banner-gradient py-16 lg:py-20">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <nav className="text-xs font-semibold text-white/80">
              <Link to="/" className="hover:text-primary">
                Home
              </Link>
              <span className="px-2">›</span>
              <span className="text-white">Case Studies</span>
            </nav>
            <h1 className="mt-5 font-display text-4xl font-extrabold text-white sm:text-5xl">
              Featured <span className="text-primary">Work</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base text-white/80 sm:text-lg">
              Real campaigns, real numbers, real growth.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-24">
          <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 lg:px-8">
            {CASES.map((c) => (
              <article
                key={c.title}
                className="rounded-2xl border border-border bg-card p-7 transition-all hover:border-primary/40 hover:card-shadow lg:p-10"
              >
                <span className="inline-flex w-fit rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary">
                  {c.tag}
                </span>
                <h2 className="mt-5 font-display text-2xl font-extrabold text-navy sm:text-3xl">
                  {c.title}
                </h2>
                <p className="mt-2 font-display text-lg font-bold text-primary">{c.result}</p>
                <div className="mt-8 grid gap-8 lg:grid-cols-3">
                  <div>
                    <h3 className="font-display text-sm font-bold uppercase tracking-widest text-navy">
                      Challenge
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {c.challenge}
                    </p>
                  </div>
                  <div>
                    <h3 className="font-display text-sm font-bold uppercase tracking-widest text-navy">
                      Approach
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {c.approach}
                    </p>
                  </div>
                  <div>
                    <h3 className="font-display text-sm font-bold uppercase tracking-widest text-navy">
                      Result
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {c.outcome}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="gradient-orange py-20 text-primary-foreground lg:py-24">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
              Ready for results like these?
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-base font-light leading-relaxed sm:text-lg">
              Book a free consultation and get a clear, no-obligation plan for your business.
            </p>
            <Link
              to="/contact"
              className="mt-8 inline-flex rounded-full bg-background px-8 py-4 text-sm font-bold text-primary transition-transform hover:-translate-y-0.5"
            >
              Get Free Consultation
            </Link>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
