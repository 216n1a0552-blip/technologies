import { createFileRoute } from "@tanstack/react-router";
import { SERVICES } from "@/data/services";
import { SITE_URL } from "@/data/contact";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: () => {
        const today = new Date().toISOString().slice(0, 10);
        const urls = [
          { loc: "/", priority: "1.0" },
          { loc: "/services", priority: "0.9" },
          { loc: "/contact", priority: "0.8" },
          { loc: "/about", priority: "0.8" },
          { loc: "/case-studies", priority: "0.8" },
          { loc: "/blog", priority: "0.7" },

          ...SERVICES.map((s) => ({ loc: `/services/${s.slug}`, priority: "0.8" })),
        ];
        const body = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls
  .map(
    (u) =>
      `  <url><loc>${SITE_URL}${u.loc}</loc><lastmod>${today}</lastmod><changefreq>weekly</changefreq><priority>${u.priority}</priority></url>`,
  )
  .join("\n")}
</urlset>`;
        return new Response(body, {
          headers: {
            "content-type": "application/xml; charset=utf-8",
            "cache-control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
