import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { FAQ } from "@/components/site/Sections";
import { FloatingActions } from "@/components/site/FloatingActions";
import { getService } from "@/data/services";
import { SITE_URL } from "@/data/contact";
import { serviceSchema, faqSchema, ldScript } from "@/data/schema";
import { Check } from "lucide-react";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const service = getService(params.slug);
    if (!service) throw notFound();
    return {
      slug: service.slug,
      title: service.title,
      valueProp: service.valueProp,
      desc: service.desc,
      faqs: service.faqs,
    };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Service not found | BRANDSPIRE" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.title} Services in Hyderabad | BRANDSPIRE TECHNOLOGIES`;
    const description = `${loaderData.desc} ${loaderData.valueProp}`.slice(0, 158);
    const url = `${SITE_URL}/services/${loaderData.slug}`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        ldScript(serviceSchema({ name: loaderData.title, description: loaderData.desc, url })),
        ldScript(faqSchema(loaderData.faqs)),
      ],
    };
  },
  component: ServicePage,
});


function ServicePage() {
  const { slug } = Route.useParams();
  const service = getService(slug)!;
  const Icon = service.icon;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero */}
        <section className="relative overflow-hidden border-b border-border banner-gradient py-16 lg:py-24">
          <div className="pointer-events-none absolute -right-32 -top-40 size-[30rem] rounded-full bg-primary/25 blur-3xl" />
          <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
            <nav className="text-xs font-semibold text-white/80">
              <Link to="/" className="hover:text-primary">
                Home
              </Link>
              <span className="px-2">›</span>
              <Link to="/services" className="hover:text-primary">
                Services
              </Link>
              <span className="px-2">›</span>
              <span className="text-white">{service.navTitle}</span>
            </nav>

            <span className="mt-6 inline-flex size-14 items-center justify-center rounded-2xl gradient-orange text-primary-foreground glow-orange">
              <Icon className="size-7" />
            </span>

            <h1 className="mt-6 max-w-3xl font-display text-4xl font-extrabold leading-[1.08] text-white sm:text-5xl">
              {service.heroLead} <span className="text-primary">{service.heroHighlight}</span>
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-white/80 sm:text-lg">
              {service.valueProp}
            </p>
            <Link
              to="/contact"
              className="mt-8 inline-flex rounded-full bg-primary px-7 py-3.5 text-sm font-bold text-primary-foreground transition-all hover:glow-orange hover:brightness-105"
            >
              Get Free Consultation
            </Link>

          </div>
        </section>

        {/* Includes */}
        <section className="py-20 lg:py-24">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
              What This Service <span className="text-primary">Includes</span>
            </h2>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {service.includes.map((f) => (
                <div
                  key={f.title}
                  className="rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/40 hover:card-shadow"
                >
                  <span className="mb-4 inline-flex size-11 items-center justify-center rounded-xl bg-accent text-primary">
                    <Check className="size-5" />
                  </span>
                  <h3 className="font-display text-lg font-bold text-navy">{f.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="border-t border-border bg-muted py-20 lg:py-24">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
              Our Process for <span className="text-primary">{service.navTitle}</span>
            </h2>
            <div className="mt-12 grid gap-10 lg:grid-cols-4">
              {service.process.map((s, i) => (
                <div key={s.title}>
                  <span className="inline-flex size-12 items-center justify-center rounded-full border-2 border-primary bg-background font-display text-lg font-extrabold text-navy">
                    {i + 1}
                  </span>
                  <h3 className="mt-5 font-display text-lg font-bold text-navy">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits */}
        <section className="bg-navy py-20 text-navy-foreground lg:py-24">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
              Why It <span className="text-primary">Matters</span>
            </h2>
            <div className="mt-12 grid gap-10 lg:grid-cols-3">
              {service.benefits.map((b) => (
                <div key={b.title}>
                  <h3 className="font-display text-xl font-bold text-primary">{b.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-navy-foreground/75">{b.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="border-b border-border bg-background py-16">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <h2 className="font-display text-2xl font-extrabold text-navy sm:text-3xl">
              Results You Can <span className="text-primary">Expect</span>
            </h2>
            <div className="mt-10 grid gap-8 sm:grid-cols-3">
              {service.stats.map((s) => (
                <div key={s.label} className="rounded-2xl border border-border bg-card p-7">
                  <p className="font-display text-4xl font-extrabold text-primary">{s.value}</p>
                  <p className="mt-2 text-sm font-semibold text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <FAQ items={service.faqs} title="Questions About" highlight={service.navTitle} />

        {/* CTA */}
        <section className="gradient-orange py-20 text-primary-foreground lg:py-24">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
              Ready to grow with {service.navTitle}?
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-base font-light leading-relaxed sm:text-lg">
              Book a free consultation and get a clear, no-obligation plan for your business.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link
                to="/contact"
                className="inline-flex rounded-full bg-background px-8 py-4 text-sm font-bold text-primary transition-transform hover:-translate-y-0.5"
              >
                Book Your Free Consultation
              </Link>
              <a
                href="tel:+918143792269"
                className="inline-flex rounded-full border border-primary-foreground/50 px-8 py-4 text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5"
              >
                Call +91 81437 92269
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingActions />
    </div>

  );
}
