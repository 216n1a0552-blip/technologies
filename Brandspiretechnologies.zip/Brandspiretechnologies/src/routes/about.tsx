import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { FloatingActions } from "@/components/site/FloatingActions";
import { SITE_URL } from "@/data/contact";
import { organizationSchema, ldScript } from "@/data/schema";
import { Target, Handshake, LineChart, ShieldCheck } from "lucide-react";

const TITLE = "About Us | Digital Marketing Agency in Hyderabad | BRANDSPIRE";
const DESC =
  "Learn about BRANDSPIRE TECHNOLOGIES, a performance-driven digital marketing agency in Hyderabad helping ambitious brands grow with SEO, paid ads and content that deliver measurable ROI.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/about` }],
    scripts: [ldScript(organizationSchema)],
  }),
  component: AboutPage,
});

const VALUES = [
  {
    icon: Target,
    title: "Outcomes Over Vanity",
    desc: "We optimise for leads, pipeline and revenue — not impressions that look good on a slide.",
  },
  {
    icon: ShieldCheck,
    title: "Radical Transparency",
    desc: "Clear reporting, honest timelines and no jargon. You always know where every rupee goes.",
  },
  {
    icon: LineChart,
    title: "Compounding Growth",
    desc: "We build search, content and ad systems that get stronger every quarter instead of resetting.",
  },
  {
    icon: Handshake,
    title: "Partnership Mindset",
    desc: "We work as an extension of your team, aligned to your targets and your customers.",
  },
];

const WHY = [
  { title: "Full-Funnel Expertise", desc: "SEO, Google Ads, Meta Ads, social, content and web under one roof." },
  { title: "Senior Talent On Every Account", desc: "Strategists who have run budgets at scale, not interns with templates." },
  { title: "Data-Led Decisions", desc: "Every change is tracked, tested and tied back to a business metric." },
  { title: "Local Insight, Global Standards", desc: "Rooted in Hyderabad, benchmarked against global best practice." },
];

function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <section className="border-b border-border banner-gradient py-16 lg:py-20">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <nav className="text-xs font-semibold text-white/80">
              <Link to="/" className="hover:text-primary">
                Home
              </Link>
              <span className="px-2">›</span>
              <span className="text-white">About Us</span>
            </nav>
            <h1 className="mt-5 font-display text-4xl font-extrabold text-white sm:text-5xl">
              About <span className="text-primary">BRANDSPIRE</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base text-white/80 sm:text-lg">
              A Digital Marketing Agency built for brands that measure growth in revenue.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-24">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-2 lg:px-8">
            <div>
              <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
                Our <span className="text-primary">Story</span>
              </h2>
              <p className="mt-5 text-base leading-relaxed text-muted-foreground">
                BRANDSPIRE TECHNOLOGIES started with a simple frustration: too many businesses were
                paying for marketing activity instead of marketing results. We set out to build an
                agency where every campaign is judged by one question — did it grow the business?
              </p>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                Today we partner with e-commerce brands, local service businesses and D2C startups
                across Hyderabad and beyond, combining search, paid media and content into one
                connected growth engine.
              </p>
            </div>
            <div className="rounded-2xl border border-border bg-card p-8 card-shadow">
              <h2 className="font-display text-2xl font-extrabold text-navy">
                Our <span className="text-primary">Mission</span>
              </h2>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                To make world-class digital marketing accessible, accountable and profitable for
                ambitious brands — with strategies that compound over time and reporting you can
                actually act on.
              </p>
            </div>
          </div>
        </section>

        <section className="border-t border-border bg-muted py-20 lg:py-24">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <h2 className="font-display text-3xl font-extrabold text-navy sm:text-4xl">
              What We <span className="text-primary">Stand For</span>
            </h2>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {VALUES.map(({ icon: Icon, title, desc }) => (
                <div
                  key={title}
                  className="rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/40 hover:card-shadow"
                >
                  <span className="mb-4 inline-flex size-11 items-center justify-center rounded-xl bg-accent text-primary">
                    <Icon className="size-5" />
                  </span>
                  <h3 className="font-display text-lg font-bold text-navy">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-navy py-20 text-navy-foreground lg:py-24">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
              Why Choose <span className="text-primary">Us</span>
            </h2>
            <div className="mt-12 grid gap-10 sm:grid-cols-2">
              {WHY.map((w) => (
                <div key={w.title}>
                  <h3 className="font-display text-xl font-bold text-primary">{w.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-navy-foreground/75">{w.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="gradient-orange py-20 text-primary-foreground lg:py-24">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
              Let's build your growth engine
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-base font-light leading-relaxed sm:text-lg">
              Book a free consultation and get a clear, no-obligation plan for your business.
            </p>
            <Link
              to="/contact"
              className="mt-8 inline-flex rounded-full bg-background px-8 py-4 text-sm font-bold text-primary transition-transform hover:-translate-y-0.5"
            >
              Get Free Consultation
            </Link>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
