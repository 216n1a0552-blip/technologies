import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { FloatingActions } from "@/components/site/FloatingActions";
import { SERVICES } from "@/data/services";
import { SITE_URL } from "@/data/contact";
import { organizationSchema, ldScript } from "@/data/schema";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/services/")({
  head: () => ({
    meta: [
      { title: "Digital Marketing Services in Hyderabad | BRANDSPIRE TECHNOLOGIES" },
      {
        name: "description",
        content:
          "Explore BRANDSPIRE's digital marketing services in Hyderabad: SEO, Google Ads management, Meta Ads, social media, content, local SEO, web development and WhatsApp marketing.",
      },
      {
        property: "og:title",
        content: "Digital Marketing Services in Hyderabad | BRANDSPIRE TECHNOLOGIES",
      },
      {
        property: "og:description",
        content:
          "Eight performance-driven service lines built to grow traffic, leads and revenue for ambitious brands.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/services` }],
    scripts: [ldScript(organizationSchema)],
  }),
  component: ServicesIndex,
});


function ServicesIndex() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <section className="border-b border-border banner-gradient py-16 lg:py-20">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <nav className="text-xs font-semibold text-white/80">
              <Link to="/" className="hover:text-primary">
                Home
              </Link>
              <span className="px-2">›</span>
              <span className="text-white">Services</span>
            </nav>
            <h1 className="mt-5 font-display text-4xl font-extrabold text-white sm:text-5xl">
              Our <span className="text-primary">Services</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base text-white/80 sm:text-lg">
              Full-funnel digital marketing — from first impression to closed sale.
            </p>
          </div>
        </section>

        <section className="py-16 lg:py-20">
          <div className="mx-auto grid max-w-7xl gap-6 px-5 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
            {SERVICES.map(({ icon: Icon, title, desc, slug }) => (
              <article
                key={slug}
                className="group flex flex-col rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/40 hover:card-shadow"
              >
                <span className="mb-5 inline-flex size-12 items-center justify-center rounded-xl bg-accent text-primary transition-colors group-hover:gradient-orange group-hover:text-primary-foreground">
                  <Icon className="size-6" />
                </span>
                <h2 className="font-display text-lg font-bold leading-snug text-navy">{title}</h2>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{desc}</p>
                <Link
                  to="/services/$slug"
                  params={{ slug }}
                  className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold text-primary"
                >
                  Learn More
                  <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </article>
            ))}
          </div>
        </section>
      </main>
      <Footer />
      <FloatingActions />
    </div>

  );
}
