import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { FloatingActions } from "@/components/site/FloatingActions";
import { SITE_URL } from "@/data/contact";
import { organizationSchema, ldScript } from "@/data/schema";
import { Newspaper } from "lucide-react";

const TITLE = "Digital Marketing Blog | Insights & Ideas | BRANDSPIRE TECHNOLOGIES";
const DESC =
  "Practical SEO, Google Ads, WhatsApp and content marketing insights from the BRANDSPIRE TECHNOLOGIES team — a Digital Marketing Agency in Hyderabad.";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/blog` }],
    scripts: [ldScript(organizationSchema)],
  }),
  component: BlogPage,
});

const POSTS = [
  {
    tag: "SEO",
    title: "5 SEO Trends Shaping 2026",
    excerpt:
      "AI overviews, entity-first content and the death of thin blog posts — what actually moves rankings this year.",
  },
  {
    tag: "Google Ads",
    title: "How to Lower Your Google Ads CPC",
    excerpt:
      "Seven structural changes that reduce cost per click without shrinking your reach or lead volume.",
  },
  {
    tag: "WhatsApp",
    title: "WhatsApp Marketing: A Beginner's Guide",
    excerpt:
      "From API setup to your first broadcast — a practical playbook for high open-rate customer messaging.",
  },
];

function BlogPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <section className="border-b border-border banner-gradient py-16 lg:py-20">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <nav className="text-xs font-semibold text-white/80">
              <Link to="/" className="hover:text-primary">
                Home
              </Link>
              <span className="px-2">›</span>
              <span className="text-white">Blog</span>
            </nav>
            <h1 className="mt-5 font-display text-4xl font-extrabold text-white sm:text-5xl">
              Insights & <span className="text-primary">Ideas</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base text-white/80 sm:text-lg">
              Practical marketing thinking from the BRANDSPIRE team.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-24">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <div className="grid gap-6 lg:grid-cols-3">
              {POSTS.map((p) => (
                <article
                  key={p.title}
                  className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:border-primary/40 hover:card-shadow"
                >
                  <div className="flex aspect-[16/9] items-center justify-center bg-accent text-primary">
                    <Newspaper className="size-10" aria-hidden="true" />
                  </div>
                  <div className="flex flex-1 flex-col p-7">
                    <span className="inline-flex w-fit rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary">
                      {p.tag}
                    </span>
                    <h2 className="mt-5 font-display text-xl font-bold leading-snug text-navy">
                      {p.title}
                    </h2>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                      {p.excerpt}
                    </p>
                    <span className="mt-6 text-sm font-bold text-primary">Coming soon →</span>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="gradient-orange py-20 text-primary-foreground lg:py-24">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
              Want a strategy tailored to your brand?
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-base font-light leading-relaxed sm:text-lg">
              Book a free consultation and get a clear, no-obligation plan for your business.
            </p>
            <Link
              to="/contact"
              className="mt-8 inline-flex rounded-full bg-background px-8 py-4 text-sm font-bold text-primary transition-transform hover:-translate-y-0.5"
            >
              Get Free Consultation
            </Link>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
