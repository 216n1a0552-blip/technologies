import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { ContactForm } from "@/components/site/ContactForm";
import { CONTACT, SITE_URL } from "@/data/contact";
import { organizationSchema, ldScript } from "@/data/schema";
import contact640 from "@/assets/contact-640.webp";
import contact1280 from "@/assets/contact-1280.webp";

const TITLE = "Contact BRANDSPIRE TECHNOLOGIES | Digital Marketing Hyderabad";
const DESC =
  "Talk to BRANDSPIRE TECHNOLOGIES, a digital marketing agency in Hyderabad. Call +91 81437 92269, WhatsApp us or request a free consultation today.";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/contact` }],
    scripts: [ldScript(organizationSchema)],
  }),
  component: ContactPage,
});

const DETAILS = [
  { icon: Phone, label: "Call us", value: CONTACT.phoneDisplay, href: CONTACT.phoneHref },
  { icon: Mail, label: "Email us", value: CONTACT.email, href: CONTACT.emailHref },
  { icon: MapPin, label: "Visit us", value: CONTACT.address },
  { icon: Clock, label: "Working hours", value: "Mon – Sat, 10:00 – 19:00 IST" },
];

function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <section className="border-b border-border banner-gradient py-14 lg:py-20">
          <div className="mx-auto max-w-7xl px-5 lg:px-8">
            <nav aria-label="Breadcrumb" className="text-xs font-semibold text-white/80">
              <Link to="/" className="hover:text-primary">
                Home
              </Link>
              <span className="px-2">/</span>
              <span className="text-white">Contact</span>
            </nav>
            <h1 className="mt-4 max-w-3xl font-display text-4xl font-extrabold text-white sm:text-5xl">
              Let's talk about <span className="text-primary">growing your brand</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-white/80">
              Tell us where you want to grow and we'll come back with a clear, no-obligation plan —
              channels, budgets and the results you can realistically expect.
            </p>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[1fr_1.1fr] lg:px-8">
            <div>
              <h2 className="font-display text-2xl font-extrabold text-navy">
                Speak to a strategist today
              </h2>
              <ul className="mt-6 space-y-4">
                {DETAILS.map(({ icon: Icon, label, value, href }) => (
                  <li
                    key={label}
                    className="flex items-start gap-4 rounded-2xl border border-border bg-card p-4"
                  >
                    <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent text-primary">
                      <Icon className="size-5" />
                    </span>
                    <span>
                      <span className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">
                        {label}
                      </span>
                      {href ? (
                        <a href={href} className="font-semibold text-navy hover:text-primary">
                          {value}
                        </a>
                      ) : (
                        <span className="font-semibold text-navy">{value}</span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>

              <img
                src={contact1280}
                srcSet={`${contact640} 640w, ${contact1280} 1280w`}
                sizes="(min-width: 1024px) 40vw, 100vw"
                loading="lazy"
                decoding="async"
                width={1280}
                height={854}
                alt="BRANDSPIRE TECHNOLOGIES team member taking a client call in the Hyderabad office"
                className="mt-6 aspect-[3/2] w-full rounded-2xl object-cover card-shadow"
              />

              <div className="mt-6 overflow-hidden rounded-2xl border border-border">
                <iframe
                  title="BRANDSPIRE TECHNOLOGIES location — Hyderabad, Telangana, India"
                  src={CONTACT.mapEmbed}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="h-64 w-full border-0"
                />
              </div>
            </div>

            <div>
              <h2 className="font-display text-2xl font-extrabold text-navy">
                Request your free consultation
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Fill this in and our team will respond within one business day.
              </p>
              <div className="mt-6">
                <ContactForm source="contact-page" />
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
