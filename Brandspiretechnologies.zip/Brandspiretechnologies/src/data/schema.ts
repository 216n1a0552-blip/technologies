import { CONTACT, SITE_URL } from "./contact";

export const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": `${SITE_URL}#organization`,
  name: "BRANDSPIRE TECHNOLOGIES",
  description:
    "Performance-driven digital marketing agency in Hyderabad offering SEO, Google Ads, Meta Ads, social media, content marketing and web development.",
  url: SITE_URL,
  telephone: "+918143792269",
  email: CONTACT.email,
  address: {
    "@type": "PostalAddress",
    addressLocality: "Hyderabad",
    addressRegion: "Telangana",
    addressCountry: "IN",
  },
  areaServed: "IN",
  priceRange: "$$",
};

export function serviceSchema(input: { name: string; description: string; url: string }) {
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name: input.name,
    description: input.description,
    url: input.url,
    serviceType: input.name,
    provider: {
      "@type": "LocalBusiness",
      name: "BRANDSPIRE TECHNOLOGIES",
      telephone: "+918143792269",
      email: CONTACT.email,
      address: {
        "@type": "PostalAddress",
        addressLocality: "Hyderabad",
        addressRegion: "Telangana",
        addressCountry: "IN",
      },
    },
    areaServed: "Hyderabad, India",
  };
}

export function faqSchema(faqs: { q: string; a: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
}

export function ldScript(data: unknown) {
  return { type: "application/ld+json", children: JSON.stringify(data) };
}
