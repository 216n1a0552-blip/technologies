export const CONTACT = {
  phoneDisplay: "+91 81437 92269",
  phoneHref: "tel:+918143792269",
  email: "brandspiretechnologies@gmail.com",
  emailHref: "mailto:brandspiretechnologies@gmail.com",
  whatsapp: "https://wa.me/918143792269",
  address: "Hyderabad, Telangana, India",
  mapEmbed:
    "https://www.google.com/maps?q=Hyderabad,Telangana,India&output=embed",
} as const;

export const SITE_URL = "https://brandspire-ignite-growth.lovable.app";
