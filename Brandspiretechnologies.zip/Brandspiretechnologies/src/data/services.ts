import {
  Search,
  MousePointerClick,
  Share2,
  Users,
  PenLine,
  MapPin,
  Code2,
  MessageCircle,
  type LucideIcon,
} from "lucide-react";

export type ServiceContent = {
  slug: string;
  icon: LucideIcon;
  title: string;
  navTitle: string;
  heroLead: string;
  heroHighlight: string;
  desc: string;
  valueProp: string;
  includes: { title: string; desc: string }[];
  process: { title: string; desc: string }[];
  benefits: { title: string; desc: string }[];
  stats: { value: string; label: string }[];
  faqs: { q: string; a: string }[];
};

export const SERVICES: ServiceContent[] = [
  {
    slug: "seo",
    icon: Search,
    title: "Search Engine Optimization",
    navTitle: "Search Engine Optimization",
    heroLead: "Search Engine",
    heroHighlight: "Optimization",
    desc: "Rank higher, get found first. We build sustainable organic growth through technical SEO, content strategy and authority building.",
    valueProp:
      "Long-term organic growth that reduces your dependency on paid ads and compounds month after month.",
    includes: [
      { title: "Technical SEO Audits", desc: "Crawlability, Core Web Vitals, indexation and site architecture fixed at the root." },
      { title: "On-Page Optimization", desc: "Titles, metadata, internal linking and content structure tuned for search intent." },
      { title: "Link Building", desc: "Editorial, relevance-first backlinks that build genuine domain authority." },
      { title: "Keyword Strategy", desc: "Commercial-intent keyword mapping across your entire funnel." },
      { title: "Content SEO", desc: "Topic clusters and content briefs that own the conversations that matter." },
      { title: "Local Search Visibility", desc: "Map pack and location-level visibility for every service area." },
    ],
    process: [
      { title: "Technical & Content Audit", desc: "We benchmark your site against competitors and surface every blocker." },
      { title: "Keyword & Cluster Mapping", desc: "We build a keyword architecture aligned to revenue, not just volume." },
      { title: "On-Page & Technical Fixes", desc: "Implementation of structural, speed and content improvements." },
      { title: "Authority & Content Growth", desc: "Ongoing publishing and link acquisition to compound rankings." },
    ],
    benefits: [
      { title: "Compounding Traffic", desc: "Organic results keep working long after the work is done." },
      { title: "Lower Cost Per Lead", desc: "Reduce reliance on paid media as organic share grows." },
      { title: "Qualified Visitors", desc: "Intent-matched traffic that converts, not just clicks." },
    ],
    stats: [
      { value: "210%", label: "Avg. organic traffic lift" },
      { value: "340+", label: "Keywords ranked top 10" },
      { value: "5 mo", label: "Typical time to breakout" },
    ],
    faqs: [
      { q: "How long until SEO shows results?", a: "Early movement typically appears in 8–12 weeks, with compounding growth from month four onward." },
      { q: "Do you guarantee rankings?", a: "No credible agency can. We guarantee process, transparency and measurable progress against agreed KPIs." },
      { q: "Do you write the content too?", a: "Yes — SEO-driven briefs, writing, optimization and publishing are all included." },
    ],
  },
  {
    slug: "google-ads",
    icon: MousePointerClick,
    title: "Google Ads Management",
    navTitle: "Google Ads",
    heroLead: "Google Ads",
    heroHighlight: "Management",
    desc: "High-intent traffic that converts. Precision-targeted PPC campaigns engineered for maximum ROI.",
    valueProp:
      "Immediate, high-intent traffic with measurable ROI — every rupee tracked from click to conversion.",
    includes: [
      { title: "Search Campaigns", desc: "Bottom-funnel keyword capture built around buying intent." },
      { title: "Shopping Ads", desc: "Feed optimization and product campaigns that drive e-commerce revenue." },
      { title: "Display Remarketing", desc: "Bring warm visitors back with sequenced creative." },
      { title: "YouTube Ads", desc: "Video campaigns that build demand and retarget at scale." },
      { title: "Conversion Tracking Setup", desc: "Clean GA4, GTM and offline conversion tracking you can trust." },
      { title: "Bid Strategy Optimization", desc: "Smart bidding tuned to profit, not just cost per click." },
    ],
    process: [
      { title: "Account & Competitor Audit", desc: "We review structure, spend waste and competitor positioning." },
      { title: "Campaign Architecture", desc: "Rebuild around intent tiers, budgets and clear conversion goals." },
      { title: "Launch & Tracking", desc: "Airtight measurement before a single rupee is spent." },
      { title: "Optimize & Scale", desc: "Weekly bid, creative and keyword refinement to grow profitably." },
    ],
    benefits: [
      { title: "Instant Visibility", desc: "Be in front of buyers the day your campaign goes live." },
      { title: "Full Attribution", desc: "Know exactly which keyword produced which sale." },
      { title: "Scalable Spend", desc: "Increase budget only where the numbers justify it." },
    ],
    stats: [
      { value: "3.2x", label: "Average return on ad spend" },
      { value: "-38%", label: "Average cost per lead" },
      { value: "72h", label: "From kickoff to launch" },
    ],
    faqs: [
      { q: "What budget should I start with?", a: "Most clients start between ₹50,000 and ₹2,00,000 per month depending on industry competitiveness." },
      { q: "Is ad spend included in your fee?", a: "No — media spend goes directly to Google. Our management fee is separate and transparent." },
      { q: "How soon do we see leads?", a: "Typically within the first two weeks, with efficiency improving through ongoing optimization." },
    ],
  },
  {
    slug: "meta-ads",
    icon: Share2,
    title: "Meta Ads (Facebook & Instagram)",
    navTitle: "Meta Ads",
    heroLead: "Meta Ads",
    heroHighlight: "(Facebook & Instagram)",
    desc: "Scroll-stopping campaigns across Facebook and Instagram that turn attention into action.",
    valueProp:
      "Scroll-stopping creative paired with precision targeting that turns attention into revenue.",
    includes: [
      { title: "Audience Research", desc: "Interest, lookalike and behavioural audience architecture." },
      { title: "Creative Ad Design", desc: "Thumb-stopping statics, carousels and short-form video." },
      { title: "A/B Testing", desc: "Structured creative and angle testing to find winners fast." },
      { title: "Retargeting Funnels", desc: "Full-funnel sequences from first view to purchase." },
      { title: "Pixel & Conversion API Setup", desc: "Server-side tracking for accurate post-iOS measurement." },
      { title: "Budget Optimization", desc: "Spend allocation that follows performance in real time." },
    ],
    process: [
      { title: "Offer & Audience Mapping", desc: "We define the hook, the offer and who it's for." },
      { title: "Creative Production", desc: "Batch creative built for testing, not one-off posts." },
      { title: "Structured Testing", desc: "Isolate the winning angle, audience and format." },
      { title: "Scale the Winners", desc: "Increase spend on proven combinations while refreshing creative." },
    ],
    benefits: [
      { title: "Demand Creation", desc: "Reach buyers before they start searching." },
      { title: "Creative Advantage", desc: "Better creative beats better bidding on Meta." },
      { title: "Efficient Retargeting", desc: "Recover abandoned interest at a fraction of cold CPA." },
    ],
    stats: [
      { value: "4.1x", label: "Best-in-class ROAS" },
      { value: "92%", label: "Avg. follower growth lift" },
      { value: "12+", label: "Creatives tested monthly" },
    ],
    faqs: [
      { q: "Do you produce the creative?", a: "Yes — copy, design and short-form video editing are all handled in-house." },
      { q: "Will iOS tracking limits hurt performance?", a: "We deploy Conversions API and server-side events to recover signal loss." },
      { q: "How often is creative refreshed?", a: "Every two to four weeks, or sooner if frequency and CTR indicate fatigue." },
    ],
  },
  {
    slug: "social-media-marketing",
    icon: Users,
    title: "Social Media Marketing",
    navTitle: "Social Media Marketing",
    heroLead: "Social Media",
    heroHighlight: "Marketing",
    desc: "Build a brand people follow. Strategy, content and community management that grows real engagement.",
    valueProp: "Brand visibility and an engaged community that compounds into customers.",
    includes: [
      { title: "Content Calendars", desc: "Monthly planned, on-brand content mapped to campaigns." },
      { title: "Community Management", desc: "Daily replies, DMs and comment moderation." },
      { title: "Reels & Short-Form Video", desc: "Native vertical video built for reach." },
      { title: "Influencer Collaboration", desc: "Creator sourcing, briefing and performance tracking." },
      { title: "Platform Strategy", desc: "Tailored playbooks for Instagram, LinkedIn and Facebook." },
      { title: "Analytics & Growth Tracking", desc: "Monthly reporting on reach, engagement and conversions." },
    ],
    process: [
      { title: "Brand & Audience Discovery", desc: "Tone, pillars and audience insight defined up front." },
      { title: "Content System Build", desc: "Templates, formats and a repeatable monthly calendar." },
      { title: "Publish & Engage", desc: "Consistent posting plus active community management." },
      { title: "Measure & Iterate", desc: "Double down on the formats that actually drive growth." },
    ],
    benefits: [
      { title: "Top-of-Mind Brand", desc: "Stay visible where your audience spends its attention." },
      { title: "Owned Audience", desc: "Grow a following you don't have to rent from ad platforms." },
      { title: "Social Proof", desc: "An active profile shortens the path to trust." },
    ],
    stats: [
      { value: "92%", label: "Avg. follower growth" },
      { value: "3.4x", label: "Engagement rate lift" },
      { value: "20+", label: "Assets published monthly" },
    ],
    faqs: [
      { q: "Which platforms do you manage?", a: "Instagram, Facebook, LinkedIn, YouTube Shorts and X, chosen by where your audience is." },
      { q: "Do you shoot content?", a: "We handle editing and direction, and can coordinate shoots on request." },
      { q: "How many posts per month?", a: "Packages typically range from 12 to 30 assets including reels and stories." },
    ],
  },
  {
    slug: "content-marketing",
    icon: PenLine,
    title: "Content Marketing",
    navTitle: "Content Marketing",
    heroLead: "Content",
    heroHighlight: "Marketing",
    desc: "Stories that sell. SEO-driven content that builds authority and nurtures leads into customers.",
    valueProp: "Authority-building content that nurtures leads from first read to signed deal.",
    includes: [
      { title: "Blog & Article Writing", desc: "Research-led long-form built to rank and convert." },
      { title: "SEO Content Strategy", desc: "Topic clusters mapped to search demand and buying stages." },
      { title: "Email Newsletters", desc: "Recurring nurture that keeps your list warm." },
      { title: "Case Studies & Whitepapers", desc: "Proof assets your sales team can actually use." },
      { title: "Video Scripting", desc: "Scripts for explainers, ads and short-form social." },
      { title: "Content Distribution", desc: "Repurposing and syndication so each asset works harder." },
    ],
    process: [
      { title: "Content Audit", desc: "Identify gaps, cannibalisation and quick-win refreshes." },
      { title: "Editorial Roadmap", desc: "A quarterly calendar tied to keywords and funnel stages." },
      { title: "Production", desc: "Briefs, drafting, editing and on-page optimization." },
      { title: "Distribute & Refresh", desc: "Promote, repurpose and update to sustain performance." },
    ],
    benefits: [
      { title: "Category Authority", desc: "Become the source buyers trust in your space." },
      { title: "Lead Nurturing", desc: "Content that moves prospects toward a decision." },
      { title: "Sales Enablement", desc: "Assets that shorten sales cycles and answer objections." },
    ],
    stats: [
      { value: "6x", label: "More organic entry pages" },
      { value: "48%", label: "Higher lead-to-MQL rate" },
      { value: "8+", label: "Assets produced monthly" },
    ],
    faqs: [
      { q: "Is the content written by humans?", a: "Yes — written by specialists, with research and editing at every stage." },
      { q: "Do you handle publishing?", a: "We publish, optimize and internally link directly in your CMS." },
      { q: "Can you match our tone of voice?", a: "We build a documented voice guide during onboarding and write to it." },
    ],
  },
  {
    slug: "local-seo",
    icon: MapPin,
    title: "Local SEO",
    navTitle: "Local SEO",
    heroLead: "Local",
    heroHighlight: "SEO",
    desc: "Own your neighborhood. Get found by customers searching near you on Google Maps and local search.",
    valueProp: 'Dominate "near me" searches and turn map visibility into walk-ins and calls.',
    includes: [
      { title: "Google Business Profile Optimization", desc: "Categories, services, photos and posts fully optimized." },
      { title: "Local Citations", desc: "Consistent NAP listings across high-trust directories." },
      { title: "Review Management", desc: "Review generation flows and response templates." },
      { title: "Local Keyword Targeting", desc: "City and neighbourhood-level keyword coverage." },
      { title: "Map Pack Ranking", desc: "Proximity, prominence and relevance signals strengthened." },
      { title: "Location Page Optimization", desc: "Unique, indexable pages for every service area." },
    ],
    process: [
      { title: "Local Audit", desc: "Profile health, citation accuracy and grid ranking baseline." },
      { title: "Profile & Citation Cleanup", desc: "Fix inconsistencies that suppress map visibility." },
      { title: "Local Content & Reviews", desc: "Location pages plus a steady review engine." },
      { title: "Grid Tracking & Scaling", desc: "Monitor rank by geo-grid and expand coverage." },
    ],
    benefits: [
      { title: "Higher Foot Traffic", desc: "Show up when nearby customers are ready to buy." },
      { title: "Free Clicks", desc: "Map pack visibility drives calls without ad spend." },
      { title: "Stronger Trust", desc: "Reviews and complete profiles win the click." },
    ],
    stats: [
      { value: "4x", label: "More local leads" },
      { value: "Top 3", label: "Map pack placements" },
      { value: "+180%", label: "Direction requests" },
    ],
    faqs: [
      { q: "How many locations can you manage?", a: "From a single storefront to multi-location franchises with dedicated pages each." },
      { q: "Can you fix a suspended profile?", a: "Yes — we handle reinstatement requests and compliance corrections." },
      { q: "How fast is the map pack impact?", a: "Most clients see grid movement within 30–60 days of cleanup." },
    ],
  },
  {
    slug: "website-development",
    icon: Code2,
    title: "Website Development",
    navTitle: "Website Development",
    heroLead: "Website",
    heroHighlight: "Development",
    desc: "Fast, conversion-optimized websites designed to turn visitors into leads.",
    valueProp: "Conversion-optimized, fast-loading websites engineered to turn traffic into revenue.",
    includes: [
      { title: "Custom Website Design", desc: "Brand-led design systems, not recycled templates." },
      { title: "Landing Page Development", desc: "Campaign pages built purely to convert paid traffic." },
      { title: "E-commerce Development", desc: "Storefronts with frictionless checkout journeys." },
      { title: "Speed & Performance Optimization", desc: "Core Web Vitals in the green on real devices." },
      { title: "Mobile Responsiveness", desc: "Designed mobile-first, tested across breakpoints." },
      { title: "CMS Integration", desc: "Edit content yourself without touching code." },
    ],
    process: [
      { title: "Discovery & Wireframes", desc: "Goals, user journeys and page structure agreed first." },
      { title: "Design", desc: "High-fidelity, on-brand designs reviewed with you." },
      { title: "Build & QA", desc: "Clean, accessible, fast code tested on every device." },
      { title: "Launch & Optimize", desc: "Analytics, heatmaps and iterative CRO after go-live." },
    ],
    benefits: [
      { title: "Higher Conversion", desc: "Every section designed around a next action." },
      { title: "Faster Load Times", desc: "Speed directly improves rankings and revenue." },
      { title: "Full Ownership", desc: "You own the code, content and hosting decisions." },
    ],
    stats: [
      { value: "<1.5s", label: "Typical load time" },
      { value: "+62%", label: "Conversion rate lift" },
      { value: "100%", label: "Mobile responsive" },
    ],
    faqs: [
      { q: "How long does a website take?", a: "Most marketing sites launch in four to eight weeks depending on scope." },
      { q: "Can you redesign an existing site?", a: "Yes — including migrations that preserve existing SEO equity." },
      { q: "Do you offer ongoing support?", a: "Maintenance, updates and CRO retainers are available post-launch." },
    ],
  },
  {
    slug: "whatsapp-marketing",
    icon: MessageCircle,
    title: "WhatsApp Marketing",
    navTitle: "WhatsApp Marketing",
    heroLead: "WhatsApp",
    heroHighlight: "Marketing",
    desc: "Direct, personal, high-converting outreach through India's most-used messaging platform.",
    valueProp: "Direct, high-open-rate customer communication on the channel your customers already use.",
    includes: [
      { title: "Bulk Campaign Setup", desc: "Compliant, template-approved broadcast campaigns." },
      { title: "Automated Chatbots", desc: "Instant replies and qualification around the clock." },
      { title: "Catalog & Product Sharing", desc: "Shoppable catalogs delivered straight into chat." },
      { title: "Lead Nurturing Sequences", desc: "Timed follow-ups that recover stalled enquiries." },
      { title: "Order & Booking Notifications", desc: "Automated confirmations, reminders and updates." },
      { title: "Customer Support Automation", desc: "Deflect routine queries and route the rest to humans." },
    ],
    process: [
      { title: "API & Number Setup", desc: "Business verification and WhatsApp Business API onboarding." },
      { title: "Flow Design", desc: "Map conversations, triggers and handoff points." },
      { title: "Campaign Launch", desc: "Approved templates broadcast to segmented lists." },
      { title: "Optimize & Automate", desc: "Refine copy, timing and automation based on reply data." },
    ],
    benefits: [
      { title: "Unmatched Open Rates", desc: "Messages get read in minutes, not days." },
      { title: "Two-Way Conversations", desc: "Customers reply instantly — no forms required." },
      { title: "Lower Support Load", desc: "Automation handles the repetitive questions." },
    ],
    stats: [
      { value: "95%", label: "Message open rate" },
      { value: "8x", label: "Higher reply rate vs email" },
      { value: "24/7", label: "Automated response cover" },
    ],
    faqs: [
      { q: "Is bulk WhatsApp messaging legal?", a: "Yes, via the official WhatsApp Business API with opt-in contacts and approved templates." },
      { q: "Do I need a separate number?", a: "A dedicated business number is recommended and we handle the verification." },
      { q: "Can it integrate with our CRM?", a: "Yes — leads and conversations sync into most major CRMs." },
    ],
  },
];

export const getService = (slug: string) => SERVICES.find((s) => s.slug === slug);
