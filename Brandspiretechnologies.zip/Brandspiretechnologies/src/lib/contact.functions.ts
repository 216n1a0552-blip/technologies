import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const submitEnquiry = createServerFn({ method: "POST" })
  .inputValidator((data) =>
    z
      .object({
        name: z.string().trim().min(2).max(120),
        phone: z.string().trim().min(6).max(30),
        email: z.string().trim().email().max(200),
        service: z.string().trim().max(120).optional().default(""),
        message: z.string().trim().min(5).max(4000),
        source: z.string().trim().max(60).optional().default("website"),
      })
      .parse(data),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { error } = await supabaseAdmin.from("contact_submissions").insert({
      name: data.name,
      phone: data.phone,
      email: data.email,
      service: data.service || null,
      message: data.message,
      source: data.source || "website",
    });

    if (error) {
      console.error("[contact] insert failed", error.message);
      throw new Error("Could not save your enquiry. Please try again.");
    }

    return { ok: true as const };
  });
