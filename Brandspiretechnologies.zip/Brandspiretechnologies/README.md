# BRANDSPIRE

Here's the expanded version with full, specific copy for every section — not placeholder text — ready to drop into Lovable.

Lovable Prompt: BRANDSPIRE TECHNOLOGIES Website

Build a premium, corporate digital marketing agency website for BRANDSPIRE TECHNOLOGIES. Use the uploaded logo throughout, preserving its original proportions — do not crop, stretch, recolour, or redesign it.

Colour System Primary: Bright Orange (#FF6B00 range) + White — dominant across the site. Secondary: Deep Navy Blue (#0B1F3A range) — headings, body text, icons, borders, contrast. White backgrounds for most sections, orange gradients for highlights, orange CTAs, navy headings, orange hover states, soft orange glows/shadows, navy+orange icons, light-grey section dividers. No purple, green, or pink anywhere.

HEADER White sticky header, logo left, nav items: Home | Services | About Us | Case Studies | Blog | Contact — in navy, each with an orange underline animation on hover. Right side: orange "Get Free Consultation" button.

HERO SECTION Headline (navy, key words in orange): "Grow Your Brand. Inspire Greater Success."

Subheading: "BRANDSPIRE TECHNOLOGIES helps businesses increase online visibility, generate quality leads and achieve measurable growth through creative and performance-driven digital marketing strategies."

Supporting line under the buttons: "Trusted by growing brands across industries — from local businesses to national enterprises."

Buttons: "Start Growing" (orange fill, white text) / "Explore Services" (white fill, orange border, navy text).

Hero visual: an animated dashboard mockup (orange/white/navy) with live-feel widgets:

Website Traffic — line graph trending upward, "+184% in 6 months"

Lead Generation — counter ticking up, "1,240 Qualified Leads This Quarter"

Social Growth — bar chart, "Follower Growth +92%"

Search Rankings — "Keywords in Top 10: 340+"

Campaign Performance — donut chart showing spend-to-conversion ratio

Conversion Rate — "+3.2x Average ROI"

SERVICES SECTION Section heading: "What We Do Best" / subheading: "Full-funnel digital marketing built to convert."

Eight cards, each with an orange icon, navy heading, one-line description, and a "Learn More →" link in orange:

Search Engine Optimization — "Rank higher, get found first. We build sustainable organic growth through technical SEO, content strategy and authority building."

Google Ads — "High-intent traffic that converts. Precision-targeted PPC campaigns engineered for maximum ROI."

Meta Ads — "Scroll-stopping campaigns across Facebook and Instagram that turn attention into action."

Social Media Marketing — "Build a brand people follow. Strategy, content and community management that grows real engagement."

Content Marketing — "Stories that sell. SEO-driven content that builds authority and nurtures leads into customers."

Local SEO — "Own your neighborhood. Get found by customers searching near you on Google Maps and local search."

Website Development — "Fast, conversion-optimized websites designed to turn visitors into leads."

WhatsApp Marketing — "Direct, personal, high-converting outreach through India's most-used messaging platform."

WHY CHOOSE US Deep navy background, white text, orange icons. Heading: "Why Brands Choose BRANDSPIRE"

ROI-Focused Campaigns — "Every rupee is tracked. We optimize toward revenue, not vanity metrics."

Custom Marketing Strategies — "No templates. Every strategy is built around your business goals and audience."

Transparent Reporting — "Real-time dashboards and monthly reports — you always know where your budget goes."

Creative Digital Solutions — "Bold creative that gets noticed, backed by data that gets results."

Dedicated Client Support — "A dedicated account manager, always reachable, always accountable."

Measurable Business Growth — "We measure success in leads, sales and revenue — not impressions."

CALL-TO-ACTION SECTION Orange gradient background. Heading (white): "Ready to Build a Powerful Digital Brand?" Subtext (white, lighter weight): "Let's create a growth strategy tailored to your business — no obligation, just a clear plan forward." Button: "Book Your Free Consultation" (white fill, orange text).

FOOTER Deep navy background. Column 1: Logo + short line — "BRANDSPIRE TECHNOLOGIES — Performance-driven digital marketing for ambitious brands." Column 2 (orange heading "Services"): links to all 8 services. Column 3 (orange heading "Company"): About Us, Case Studies, Blog, Careers, Contact. Column 4 (orange heading "Get in Touch"): email, phone, address, orange social icons (Instagram, LinkedIn, Facebook, X) with orange hover glow. Bottom bar: "© 2026 BRANDSPIRE TECHNOLOGIES. All rights reserved." in white/light-grey.

Overall Feel: Premium, corporate, creative, energetic, trustworthy, modern, conversion-focused — a unique, international-level agency website built specifically around the BRANDSPIRE TECHNOLOGIES brand, with the orange/white/navy identity held consistently across every section.

Want me to build this out as an actual working prototype here (HTML/React) so you can preview it before pasting into Lovable?

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://brandspiretechnologiess.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/822f0187-bbb4-4ec7-a070-033f9c9bfb05).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
